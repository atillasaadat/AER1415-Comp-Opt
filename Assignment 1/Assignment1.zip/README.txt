To run assn1.py in Ubuntu, run the following commands, assuming python3 and pip are installed:

sudo apt-get update && sudo apt-get upgrade
pip install numpy matplotlib IPython
python assn1.py

To run various sections of the code, comment out the sectioned lines from Lines 325 onwards